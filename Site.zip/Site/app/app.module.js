﻿(function () {
    'use strict';

    angular.module('app', [
        'ngResource',
        'ui.router',
        'ui.bootstrap'
    ]);
})();